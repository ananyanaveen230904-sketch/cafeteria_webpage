// Smooth scrolling for nav links
const navLinks = document.querySelectorAll('.nav-links a');

navLinks.forEach(link => {
  link.addEventListener('click', e => {
    e.preventDefault();
    const targetId = link.getAttribute('href').substring(1);
    const targetSection = document.getElementById(targetId);
    targetSection.scrollIntoView({ behavior: 'smooth' });
  });
});

// Contact form validation
const form = document.querySelector('.contact-form');

form.addEventListener('submit', function(e) {
  const name = form.querySelector('input[type="text"]');
  const email = form.querySelector('input[type="email"]');
  const message = form.querySelector('textarea');

  if (name.value.trim() === '' || email.value.trim() === '' || message.value.trim() === '') {
    e.preventDefault();
    alert('Please fill in all fields before submitting!');
  } else {
    alert('Thank you! Your message has been sent.');
  }
});
